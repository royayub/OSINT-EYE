import tkinter as tk
from tkinter import ttk
import subprocess
from PIL import Image, ImageTk


# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

# Add the updated switch_theme() function and new change_widget_theme() function here
def change_widget_theme(widget, bg_color, fg_color=None):
    widget_classes = (tk.Label, ttk.Button, tk.Frame, ttk.Scrollbar, tk.Canvas)

    for child in widget.winfo_children():
        if isinstance(child, widget_classes):
            child.config(bg=bg_color)
            if fg_color is not None and isinstance(child, tk.Label):
                child.config(fg=fg_color)
        change_widget_theme(child, bg_color, fg_color)


def switch_theme():
    global dark_theme
    dark_theme = not dark_theme

    if dark_theme:
        theme_button.config(text="Switch to Light Theme")
        change_widget_theme(root, '#333333', 'red')
        border_frame.config(bg='#666666')
        scrollbar.config(bg='#666666', troughcolor='#333333', activebackground='#999999')
        
    else:
        theme_button.config(text="Switch to Dark Theme")
        change_widget_theme(root, '#f0f0f0', 'blue')
        border_frame.config(bg='#f0f0f0')
        scrollbar.config(bg='#f0f0f0', troughcolor='#f0f0f0', activebackground='#007acc')
# Create the main window
root = tk.Tk()
root.title("OSINT Github Tools")
root.geometry("1152x216")



# Load the wallpaper background image
wallpaper = Image.open("wallpaper.jpg")
wallpaper = wallpaper.resize((root.winfo_width(), root.winfo_height()), Image.ANTIALIAS)
wallpaper = ImageTk.PhotoImage(wallpaper)

# Create a label for the wallpaper background
wallpaper_label = tk.Label(root, image=wallpaper)
wallpaper_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create a frame with a border for the entire application
border_frame = tk.Frame(root, bg='#f0f0f0', bd=5)
border_frame.pack(expand=True, fill=tk.BOTH)

# Create a frame for the title label and logo
#title_frame = tk.Frame(border_frame, bg='white')
#title_frame.pack(pady=10, fill=tk.X)

# Load the logo image
#logo = Image.open("logo.png")
#logo = logo.resize((130, 180), Image.ANTIALIAS)
#logo = ImageTk.PhotoImage(logo)

# Create a label for the logo
#logo_label = tk.Label(title_frame, image=logo, bg='white')
#logo_label.pack(side=tk.LEFT, padx=(10, 0))

# Create a title label
#title = tk.Label(title_frame, text="OSINT EYE : GITHUB TOOLS", font=("Helvetica", 34, "bold"), fg="blue", bg="/home/attacker/Desktop/Gittool/O1.png")
#title.pack(side=tk.LEFT, padx=(10, 0))

# Function to resize the background image when the window is resized
original_image = Image.open("/home/attacker/Desktop/Gittool/O1.png")
image_width, image_height = original_image.size

root.geometry(f"{image_width}x{image_height}")

def resize_bg_image(event):
    global bg_image_label, original_image, image_width, image_height

    # Calculate the new size while maintaining the aspect ratio
    new_width = event.width
    new_height = int(new_width * image_height / image_width)

    # Resize the image using the BICUBIC filter
    bg_image_resized = original_image.resize((new_width, new_height), Image.BICUBIC)
    bg_image = ImageTk.PhotoImage(bg_image_resized)
    bg_image_label.config(image=bg_image)

# Load the original image
bg_image = Image.open("/home/attacker/Desktop/Gittool/O1.png")
bg_image = ImageTk.PhotoImage(bg_image)

# Create a label for the 1.png image and place it on the border_frame
bg_image_label = tk.Label(border_frame, image=bg_image)
bg_image_label.place(x=0, y=0, relwidth=1, relheight=1)

# Bind the resize event to the resize_bg_image function
root.bind('<Configure>', resize_bg_image)
# Load the 1.png image
#bg_image = Image.open("/home/attacker/Desktop/Gittool/O1.png")
#bg_image = bg_image.resize((root.winfo_width(), root.winfo_height()), Image.ANTIALIAS)
#bg_image = ImageTk.PhotoImage(bg_image)

# Create a label for the 1.png image and place it on the border_frame
#bg_image_label = tk.Label(border_frame, image=bg_image)
#bg_image_label.place(x=0, y=0, relwidth=1, relheight=1)
# Create a style for the theme switch button
theme_button_style = ttk.Style()
theme_button_style.configure('ThemeButton.TButton', background='#007acc', foreground='white', font=('Helvetica', 12))
theme_button_style.map('ThemeButton.TButton',
          foreground=[('active', 'white')],
          background=[('active', 'black')])
# Create a button to switch between dark and light theme
dark_theme = False
theme_button = ttk.Button(border_frame, text="Switch to Dark Theme", command=switch_theme, style='ThemeButton.TButton')
theme_button.pack(side=tk.TOP, pady=100, anchor='e', padx=10)

# ... (rest of your code) ...

# Create a style for the button
style = ttk.Style()
style.configure('Custom.TButton', foreground='white', background='#007acc', font=('Helvetica', 14))
# Create a style for the button when hovered
style.map('Custom.TButton',
          foreground=[('active', 'white')],
          background=[('active', 'black')])

# Load the PDF icon image
pdf_icon = Image.open('pdf_icon.png')
pdf_icon = pdf_icon.resize((16, 16))
pdf_icon = ImageTk.PhotoImage(pdf_icon)
# Create a canvas to hold the categories and tools with a scrollbar
canvas = tk.Canvas(border_frame, bg='#f0f0f0', height=300)  # Set the height of the canvas
canvas.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)

# Create a vertical scrollbar for the canvas
scrollbar = ttk.Scrollbar(border_frame, orient=tk.VERTICAL, command=canvas.yview)
scrollbar.pack(side=tk.LEFT, fill=tk.Y)

# Create a frame to hold the content within the canvas
content_frame = tk.Frame(canvas, bg='#f0f0f0')
canvas.create_window((0, 0), window=content_frame, anchor=tk.NW)

canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
content_frame.bind('<Configure>', lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
# ... (rest of your code) ...

# Replace all occurrences of 'root' with 'content_frame' in the rest of your code
# For example: category_frame = tk.Frame(root, bg='#f0f0f0') becomes category_frame = tk.Frame(content_frame, bg='#f0f0f0')
# ... (previous code) ...

# Create lists of tool names and PDF file names for each category
# Add more categories as needed
category1_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
# ... (add more categories with their respective tools) ...
category2_tools = [('Tool 3', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 4', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category3_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category4_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category5_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category6_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category7_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category8_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category9_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category10_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('SkypeHunt', '/home/attacker/Desktop/Gittool/tool1.pdf', '/home/attacker/Desktop/skypehunt')]
# Create a dictionary to map category names to their corresponding tool and PDF lists
category_data = {'Email': category1_tools,
                 'Facebook': category2_tools,
                 'Twitter': category3_tools,
                 'Instagram': category4_tools,
                 'Telegram': category5_tools,
                 'WhatsApp': category6_tools,
                 'Darkweb': category7_tools,
                 'TikTok': category8_tools,
                 'YouTube': category9_tools,
                 # ... (add more categories) ...
                 'Skype': category10_tools}

# Create a frame for the category buttons
category_frame = tk.Frame(content_frame, bg='#f0f0f0')
category_frame.pack(pady=10)

# Function to show the tools and PDFs for a selected category
# ... (previous code) ...
# Create a search bar for filtering the tool and PDF buttons
search_frame = tk.Frame(content_frame, bg='#f0f0f0')
search_frame.pack(pady=10)

search_label = tk.Label(search_frame, text='Search:', bg='#f0f0f0',fg="blue")
search_label.pack(side=tk.LEFT)

search_entry = ttk.Entry(search_frame, width=30)
search_entry.pack(side=tk.LEFT, padx=10)

# Function to filter the tool and PDF buttons based on the search text
def filter_tools():
    # Get the search text and convert it to lowercase
    search_text = search_entry.get().lower()

    # Loop through all buttons and hide/show them based on the search text
    for button in button_frame.winfo_children():
        # Get the button text and convert it to lowercase
        button_text = button.cget('text').lower()

        if search_text in button_text:
            button.pack(side=tk.TOP)
        else:
            button.pack_forget()

# Bind the filter function to the search entry box
search_entry.bind('<KeyRelease>', lambda event: filter_tools())

# Function to show the tools and PDFs for a selected category or all categories
def show_tools(category):
    # Clear the current buttons
    for child in button_frame.winfo_children():
        child.destroy()

    if category is None:
        # Show all categories and their tools
        for cat in category_data.keys():
            # Add category label
            cat_label = tk.Label(button_frame, text=cat, font=("Helvetica", 14, "bold"), bg='#f0f0f0', fg="blue")
            cat_label.pack(side=tk.TOP, pady=(10, 0))

            for name, pdf_file, tool_path in category_data[cat]:
                # Create a frame for the tool button and PDF button
                button_row = tk.Frame(button_frame, bg='#f0f0f0')
                button_row.pack(side=tk.TOP, pady=5)

                # Create the PDF button with a title
                pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                                        command=lambda path=pdf_file: open_pdf(path))
                pdf_button.pack(side=tk.LEFT)

                # Create the tool button
                tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                                         command=lambda path=tool_path: launch_tool(path))
                tool_button.pack(side=tk.LEFT, padx=10, pady=5)
    else:
        # Show only the selected category's tools
        for name, pdf_file, tool_path in category_data[category]:
            # Create a frame for the tool button and PDF button
            button_row = tk.Frame(button_frame, bg='#f0f0f0')
            button_row.pack(side=tk.TOP, pady=5)

            # Create the PDF button with a title
            pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                                    command=lambda path=pdf_file: open_pdf(path))
            pdf_button.pack(side=tk.LEFT)

            # Create the tool button
            tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                                     command=lambda path=tool_path: launch_tool(path))
            tool_button.pack(side=tk.LEFT, padx=10, pady=5)

# ... (rest of the code) ...

# Run the main loop

# Loop through the categories and create a button for each one
category_buttons = []
for category in category_data.keys():
    category_button = ttk.Button(category_frame, text=category, style='Custom.TButton')
    category_button.pack(side=tk.LEFT, padx=5)
    category_buttons.append(category_button)

# Bind the button to the show_tools function for each category
for idx, category in enumerate(category_data.keys()):
    category_buttons[idx].bind('<Button-1>', lambda event, cat=category: show_tools(cat))

# Create a button to show all tools and PDFs for each category
show_all_button = ttk.Button(content_frame, text='Show All', style='Custom.TButton', command=lambda: show_tools(None))
show_all_button.pack(pady=10)

# Create a frame to hold the tool and PDF buttons
button_frame = tk.Frame(content_frame, bg='#f0f0f0')
button_frame.pack(pady=20)

# ... (rest of the code) ...

# Run the main loop
root.mainloop()
