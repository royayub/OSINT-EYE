import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

# Dictionaries for PDF and terminal launch paths
pdf_paths = {
    "Darkweb Tool 1": "/path/to/osint/tool1/pdf",
    "Darkweb Tool 2": "/path/to/osint/tool2/pdf",
    "Darkweb Tool 3": "/path/to/osint/tool3/pdf",
    "other Tool 1": "/path/to/osint/tool1/pdf",
    "other Tool 2": "/path/to/osint/tool2/pdf",
    "other Tool 3": "/path/to/osint/tool3/pdf",
    "Info Gathering Tool 1": "/path/to/info/gathering/tool1/pdf",
    "Info Gathering Tool 2": "/path/to/info/gathering/tool2/pdf",
    "Info Gathering Tool 3": "/path/to/info/gathering/tool3/pdf",
    "SOCMINT Tool 1": "/path/to/socmint/tool1/pdf",
    "SOCMINT Tool 2": "/path/to/socmint/tool2/pdf",
    "SOCMINT Tool 3": "/path/to/socmint/tool3/pdf"
}

tool_paths = {
    "Darkweb Tool 1": "/home/attacker/Documents",
    "Darkweb Tool 2": "/path/to/osint/tool2/terminal",
    "Darkweb Tool 3": "/path/to/osint/tool3/terminal",
    "other Tool 1": "/path/to/osint/tool3/terminal",
    "other Tool 2": "/path/to/osint/tool3/terminal",
    "other Tool 3": "/path/to/osint/tool3/terminal",
    "Info Gathering Tool 1": "/path/to/info/gathering/tool1/terminal",
    "Info Gathering Tool 2": "/path/to/info/gathering/tool2/terminal",
    "Info Gathering Tool 3": "/path/to/info/gathering/tool3/terminal",
    "SOCMINT Tool 1": "/home/attacker/Desktop/maskphish",
    "SOCMINT Tool 2": "/path/to/socmint/tool2/terminal",
    "SOCMINT Tool 3": "/path/to/socmint/tool3/terminal"
}


class App(tk.Tk):
    def open_selected_pdf(self):
        selected_tool = self.selected_tool.get()
        pdf_path = pdf_paths[selected_tool]
        open_pdf(pdf_path)

    def launch_selected_tool(self):
        selected_tool = self.selected_tool.get()
        tool_path = tool_paths[selected_tool]
        launch_tool(tool_path)

    def create_button(self, parent, text, command, row, column):
        button = ttk.Button(parent, text=text, command=command)
        button.grid(row=row, column=column, sticky='nsew', padx=5, pady=5)
        return button
    
    def create_first_table_button(self, parent, text, command, double_command, row, column):
        button = ttk.Button(parent, text=text)
        button.grid(row=row, column=column, sticky='nsew', padx=5, pady=5)
        button.bind('<Button-1>', lambda event: command())
        button.bind('<Double-1>', lambda event: double_command())
        return button

#Now, the single-click and double-click functionality on the first table buttons should work as expected.

    
    def toggle_tables(self, tools):
        if self.middle_frame.winfo_ismapped() and self.current_tools == tools:
            self.hide_tables()
        else:
            if self.current_tools != tools:
                self.hide_tables()
            self.show_tools(tools)
            self.middle_frame.pack(side=tk.LEFT, padx=10, pady=10)

    def toggle_third_table(self):
        if self.right_frame.winfo_ismapped():
            self.right_frame.pack_forget()
        else:
            self.right_frame.pack(side=tk.LEFT, padx=10, pady=10)
 
    def hide_tables(self):
        self.middle_frame.pack_forget()
        self.right_frame.pack_forget()

    def show_tables(self):
        self.middle_frame.pack(side=tk.LEFT, padx=10, pady=10)
        self.right_frame.pack(side=tk.LEFT, padx=10, pady=10)

    def show_tools(self, tools):
        self.current_tools = tools  # Add this line to keep track of the currently displayed tools
        for button in self.tool_buttons:
            button.grid_remove()

        for i, tool in enumerate(tools):
            self.tool_buttons[i].config(text=tool, command=lambda t=tool: self.select_tool(t))
            self.tool_buttons[i].grid(row=i, column=0)

    def select_tool(self, tool):
        self.selected_tool.set(tool)
        self.launch_button.config(command=lambda: self.launch_selected_tool())
        self.pdf_button.config(command=lambda: self.open_selected_pdf())
        self.toggle_third_table()

    def __init__(self):
        super().__init__()

        # Set the window properties
        self.title("Your Application Title")
        self.geometry("1152x720")  # Adjust the size according to your preference

        # Set the background image
        bg_image = Image.open("/home/attacker/Desktop/Gittool/2.jpg")
        bg_image = bg_image.resize((1952, 1020), Image.ANTIALIAS)
        self.background_image = ImageTk.PhotoImage(bg_image)
        self.background_label = tk.Label(self, image=self.background_image)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Set the bottom logo and title image
        top_image = Image.open("/home/attacker/Desktop/Gittool/O1.png")
        top_image = top_image.resize((1952, 216), Image.ANTIALIAS)
        self.logo_image = ImageTk.PhotoImage(top_image)
        self.logo_label = tk.Label(self, image=self.logo_image, bd=0)
        self.logo_label.pack(side=tk.TOP, fill=tk.X)

        # Create the first table
        self.left_frame = ttk.Frame(self)
        self.left_frame.pack(side=tk.LEFT, padx=10, pady=10)

        info_gathering_tools = ["Info Gathering Tool 1", "Info Gathering Tool 2", "Info Gathering Tool 3"]
        socmint_tools = ["SOCMINT Tool 1", "SOCMINT Tool 2", "SOCMINT Tool 3"]
        darkweb_tools = ["Darkweb Tool 1", "Darkweb Tool 2", "Darkweb Tool 3"]
        mis_tools = ["other Tool 1", "other Tool 2", "other Tool 3"]

        # Add a variable to store the current tools being displayed
        self.current_tools = None

    # Update the first table button creation
        self.create_first_table_button(self.left_frame, "Social Media Tools",
                                   lambda: self.toggle_tables(socmint_tools), self.hide_tables, 0, 0)
        self.create_first_table_button(self.left_frame, "Information Gathering Tools",
                                   lambda: self.toggle_tables(info_gathering_tools), self.hide_tables, 1, 0)
        self.create_first_table_button(self.left_frame, "Darkweb Search",
                                   lambda: self.toggle_tables(darkweb_tools), self.hide_tables, 2, 0)
        self.create_first_table_button(self.left_frame, "Miscellaneous",
                                   lambda: self.toggle_tables(mis_tools), self.hide_tables, 3, 0)

        #Create the second table
        self.middle_frame = ttk.Frame(self)
        self.middle_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.tools = ["Tool 1", "Tool 2", "Tool 3", "Tool 4", "Tool 5"]
        self.tool_buttons = [self.create_button(self.middle_frame, tool, None, i, 0) for i, tool in enumerate(self.tools)]

        # Create the third table
        self.right_frame = ttk.Frame(self)
        self.right_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.selected_tool = tk.StringVar()

        self.launch_button = self.create_button(self.right_frame, "Launch Tool", None, 0, 0)
        self.pdf_button = self.create_button(self.right_frame, "Open PDF", None, 1, 0)

        # Set the style for buttons
        style = ttk.Style()
        style.configure("TButton", foreground="white", background="blue", font=("Helvetica", 12), padding=10)
        # Add hover color
        style.map("TButton", background=[("active", "black")])

        # Hide all tool buttons initially
        self.show_tools([])

        # Hide the second and third tables initially
        self.middle_frame.pack_forget()
        self.right_frame.pack_forget()

if __name__ == "__main__":
    app = App()
    app.mainloop()
