import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])



# Dictionaries for PDF and terminal launch paths
pdf_paths = {
    "Tool 1": "/path/to/tool1/pdf",
    "Tool 2": "/path/to/tool2/pdf",
    "Tool 3": "/path/to/tool3/pdf",
    "Tool 4": "/path/to/tool4/pdf",
    "Tool 5": "/path/to/tool5/pdf"
}

tool_paths = {
    "Tool 1": "/path/to/tool1/terminal",
    "Tool 2": "/path/to/tool2/terminal",
    "Tool 3": "/path/to/tool3/terminal",
    "Tool 4": "/path/to/tool4/terminal",
    "Tool 5": "/path/to/tool5/terminal"
}

# Function to create a button
def create_button(parent, text, command, row, column):
    button = ttk.Button(parent, text=text, command=command)
    button.grid(row=row, column=column, sticky='nsew', padx=5, pady=5)


class App(tk.Tk):
    def open_selected_pdf(self):
        selected_tool = self.selected_tool.get()
        pdf_path = pdf_paths[selected_tool]
        open_pdf(pdf_path)

    def launch_selected_tool(self):
        selected_tool = self.selected_tool.get()
        tool_path = tool_paths[selected_tool]
        launch_tool(tool_path)

    def __init__(self):
        super().__init__()

        # Set the window properties
        self.title("Your Application Title")
        self.geometry("1152x720")  # Adjust the size according to your preference

        # Set the background image
        bg_image = Image.open("/home/attacker/Desktop/Gittool/2.jpg")
        bg_image = bg_image.resize((1152, 720), Image.ANTIALIAS)
        self.background_image = ImageTk.PhotoImage(bg_image)
        self.background_label = tk.Label(self, image=self.background_image)
        self.background_label.place(x=0, y=0, relwidth=1, relheight=1)

        # Set the bottom logo and title image
        top_image = Image.open("/home/attacker/Desktop/Gittool/O1.png")
        top_image = top_image.resize((1152, 216), Image.ANTIALIAS)
        self.logo_image = ImageTk.PhotoImage(top_image)
        self.logo_label = tk.Label(self, image=self.logo_image, bd=0)
        self.logo_label.pack(side=tk.TOP, fill=tk.X)

        # Create the first table
        self.left_frame = ttk.Frame(self)
        self.left_frame.pack(side=tk.LEFT, padx=10, pady=10)

        create_button(self.left_frame, "OSINT Tools", None, 0, 0)
        create_button(self.left_frame, "Information Gathering Tools", None, 1, 0)
        create_button(self.left_frame, "SOCMINT Tools", None, 2, 0)

        # Create the second table
        self.middle_frame = ttk.Frame(self)
        self.middle_frame.pack(side=tk.LEFT, padx=10, pady=10)

        self.tools = ["Tool 1", "Tool 2", "Tool 3", "Tool 4", "Tool 5"]

        for i, tool in enumerate(self.tools):
            create_button(self.middle_frame, tool, None, i, 0)

        # Create the third table
        self.right_frame = ttk.Frame(self)
        self.right_frame.pack(side=tk.LEFT, padx=10, pady=10)

        create_button(self.right_frame, "Launch Tool", None, 0, 0)
        create_button(self.right_frame, "Open PDF", None, 1, 0)

        # Set the style for buttons
        style = ttk.Style()
        style.configure("TButton", foreground="blue", background="white", font=("Helvetica", 12), padding=10)

if __name__ == "__main__":
    app = App()
    app.mainloop()
