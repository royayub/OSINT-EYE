import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from ttkthemes import ThemedTk
import subprocess

def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

def show_tools(category):
    for widget in tool_frame.winfo_children():
        widget.destroy()

    category_tools = category_data.get(category, [])
    for tool in category_tools:
        tool_frame_item = tk.Frame(tool_frame, bg='#f0f0f0')
        tool_frame_item.pack(side=tk.TOP, padx=5, pady=5, fill=tk.X)

        tool_button = ttk.Button(tool_frame_item, text=tool[0], style='Custom.TButton', command=lambda tool_path=tool[2]: launch_tool(tool_path))
        tool_button.pack(side=tk.LEFT)

        pdf_button = ttk.Button(tool_frame_item, text='', style='Custom.TButton', command=lambda pdf_path=tool[1]: open_pdf(pdf_path))
        pdf_button.config(image=pdf_icon)
        pdf_button.pack(side=tk.LEFT, padx=5)

root = ThemedTk(theme="arc")
root.title("OSINT EYE : GITHUB TOOLS")
root.geometry("800x600")

content_frame = tk.Frame(root)
content_frame.pack()

category_frame = tk.Frame(content_frame, bg='#f0f0f0')
category_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

tool_frame = tk.Frame(content_frame, bg='#f0f0f0')
tool_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

style = ttk.Style()
style.configure("Custom.TButton", background="#f0f0f0")

pdf_icon = Image.open('pdf_icon.png')
pdf_icon = pdf_icon.resize((16, 16))
pdf_icon = ImageTk.PhotoImage(pdf_icon)

# Create a dictionary to map category names to their corresponding tool and PDF lists
category_data = {
    'Email': [
        ('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
        ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')
    ],
    # ... (add more categories with their respective tools) ...
}

for category, tools in category_data.items():
    category_button = ttk.Button(category_frame, text=category, style='Custom.TButton', command=lambda cat=category: show_tools(cat))
    category_button.pack(side=tk.TOP, padx=5, pady=5)

root.mainloop()
