import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

# Function to display help tooltip
def create_tooltip(widget, text):
    tooltip = tk.Toplevel(widget)
    tooltip.wm_overrideredirect(True)
    label = tk.Label(tooltip, text=text, bg="white", relief=tk.SOLID, bd=1, font=("Helvetica", 9))
    label.pack()
    return tooltip

def on_enter(event, tooltip):
    widget = event.widget
    x, y, _, _ = widget.bbox("insert")
    x += widget.winfo_rootx() + 25
    y += widget.winfo_rooty() + 25
    tooltip.wm_geometry(f"+{x}+{y}")
    tooltip.deiconify()

def on_leave(event, tooltip):
    tooltip.withdraw()

# Add the updated switch_theme() function and new change_widget_theme() function here
def change_widget_theme(widget, bg_color, fg_color=None):
    widget_classes = (tk.Label, ttk.Button, tk.Frame, ttk.Scrollbar, tk.Canvas)

    for child in widget.winfo_children():
        if isinstance(child, widget_classes):
            child.config(bg=bg_color)
            if fg_color is not None and isinstance(child, tk.Label):
                child.config(fg=fg_color)
        change_widget_theme(child, bg_color, fg_color)

# Create the main window
root = tk.Tk()
root.title("OSINT Github Tools")
root.geometry("800x600")

# Load the wallpaper background image
wallpaper = Image.open("wallpaper.jpg")
wallpaper = wallpaper.resize((root.winfo_width(), root.winfo_height()), Image.ANTIALIAS)
wallpaper = ImageTk.PhotoImage(wallpaper)

# Create a label for the wallpaper background
wallpaper_label = tk.Label(root, image=wallpaper)
wallpaper_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create a frame with a border for the entire application
border_frame = tk.Frame(root, bg='#f0f0f0', bd=5)
border_frame.pack(expand=True, fill=tk.BOTH)

# Create a frame for the title label and logo
title_frame = tk.Frame(border_frame, bg='white')
title_frame.pack(pady=10, fill=tk.X)

# Load the logo image
logo = Image.open("logo.png")
logo = logo.resize((130, 180), Image.ANTIALIAS)
logo = ImageTk.PhotoImage(logo)

# Create a label for the logo
logo_label = tk.Label(title_frame, image=logo, bg='white')
logo_label.pack(side=tk.LEFT, padx=(10, 0))

# Create a title label
title = tk.Label(title_frame, text="OSINT EYE : GITHUB TOOLS", font=("Helvetica", 34, "bold"), fg="blue", bg="white")
title.pack(side=tk.LEFT, padx=(10, 0))

# Create a frame for the tools
tool_frame = tk.Frame(border_frame, bg='#f0f0f0')
tool_frame.pack(expand=True, fill=tk.BOTH)

# Add the OSINT Framework-like tool structure here
# Structure: {'Category': [{'Tool name': {'path': 'tool
# Add the OSINT Framework-like tool structure here
# Structure: {'Category': [{'Tool name': {'path': 'tool_path', 'pdf': 'pdf_path', 'help': 'help_text'}}]}
tool_structure = {
    'Category1': [
        {
            'Tool1': {
                'path': 'path/to/tool1',
                'pdf': 'path/to/tool1_doc.pdf',
                'help': 'This is a help text for Tool1'
            }
        },
        {
            'Tool2': {
                'path': 'path/to/tool2',
                'pdf': 'path/to/tool2_doc.pdf',
                'help': 'This is a help text for Tool2'
            }
        }
    ],
    'Category2': [
        {
            'Tool3': {
                'path': 'path/to/tool3',
                'pdf': 'path/to/tool3_doc.pdf',
                'help': 'This is a help text for Tool3'
            }
        }
    ]
}

# Create a function to populate the tool structure
def populate_tool_structure(frame, tool_structure):
    for category in tool_structure:
        cat_frame = tk.Frame(frame, bg='#f0f0f0')
        cat_frame.pack(fill=tk.X, pady=5)

        cat_label = tk.Label(cat_frame, text=category, font=("Helvetica", 16, "bold"), bg='#f0f0f0')
        cat_label.pack(anchor=tk.W)

        for tool_dict in tool_structure[category]:
            for tool, info in tool_dict.items():
                tool_label = tk.Label(cat_frame, text=tool, font=("Helvetica", 12), bg='#f0f0f0')
                tool_label.pack(anchor=tk.W, padx=(20, 0))

                tooltip = create_tooltip(tool_label, info['help'])
                tool_label.bind('<Enter>', lambda event, tooltip=tooltip: on_enter(event, tooltip))
                tool_label.bind('<Leave>', lambda event, tooltip=tooltip: on_leave(event, tooltip))

                tool_label.bind('<Button-1>', lambda event, path=info['path']: launch_tool(path))
                tool_label.bind('<Double-Button-1>', lambda event, path=info['pdf']: open_pdf(path))

populate_tool_structure(tool_frame, tool_structure)

# Run the main loop
root.mainloop()
