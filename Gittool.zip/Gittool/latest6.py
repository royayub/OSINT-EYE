import tkinter as tk
from tkinter import ttk
import webbrowser
from functools import partial

# Initialize the main window
root = tk.Tk()
root.geometry("800x600")
root.title("OSINT Framework")

# Function to expand or collapse a frame
def toggle_frame(frame):
    if frame.winfo_viewable():
        frame.grid_remove()
    else:
        frame.grid()

# Create a label for the OSINT Tools title
osint_tools_label = tk.Label(root, text="OSINT Tools", font=("Helvetica", 24, "bold"))
osint_tools_label.grid(row=0, column=0, padx=10, pady=10)

# Create a frame to contain the categories
category_frame = tk.Frame(root)
category_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")
category_frame.grid_remove()

# Bind the click event for the OSINT Tools label
osint_tools_label.bind("<Button-1>", lambda event, frame=category_frame: toggle_frame(frame))

# Categories and respective tools
tool_structure = {
    'Category1': {
        'Tool1': {'path': 'path/to/tool1', 'pdf': 'path/to/tool1_doc.pdf', 'help': 'This is a help text for Tool1'},
        'Tool2': {'path': 'path/to/tool2', 'pdf': 'path/to/tool2_doc.pdf', 'help': 'This is a help text for Tool2'}
    },
    'Category2': {
        'Tool3': {'path': 'path/to/tool3', 'pdf': 'path/to/tool3_doc.pdf', 'help': 'This is a help text for Tool3'}
    }
}

# Function to populate the tool structure
def populate_tool_structure(frame, tool_structure):
    for row, category in enumerate(tool_structure):
        cat_label = tk.Label(frame, text=category, font=("Helvetica", 16, "bold"))
        cat_label.grid(row=row, column=0, pady=5)

        tool_frame = tk.Frame(frame)
        tool_frame.grid(row=row, column=1, padx=10, pady=5, sticky="nsew")
        tool_frame.grid_remove()

        cat_label.bind("<Button-1>", lambda event, tool_frame=tool_frame: toggle_frame(tool_frame))

        for col, (tool, info) in enumerate(tool_structure[category].items()):
            tool_label = tk.Label(tool_frame, text=tool, font=("Helvetica", 12))
            tool_label.grid(row=0, column=col*2, padx=5, pady=5)

            # Hover help
            def on_enter(event, help_text):
                tool_label.config(text=help_text, fg="blue")

            def on_leave(event, tool_name):
                tool_label.config(text=tool_name, fg="black")

            tool_label.bind("<Enter>", partial(on_enter, help_text=info['help']))
            tool_label.bind("<Leave>", partial(on_leave, tool_name=tool))

            # PDF button
            def open_pdf(pdf_path):
                webbrowser.open_new(pdf_path)

            pdf_button = ttk.Button(tool_frame, text="PDF", command=partial(open_pdf, info['pdf']))
            pdf_button.grid(row=0, column=col*2+1, padx=5, pady=5)

populate_tool_structure(category_frame, tool_structure)

# Run the main loop
root.mainloop()
