import tkinter as tk
from tkinter import ttk
import subprocess
from PIL import Image, ImageTk

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

# Create the main window
root = tk.Tk()
root.title("My Application")
root.geometry("400x400")
root.configure(bg='#007acc')  # Set the background color for the border

# Create a frame with a border for the entire application
border_frame = tk.Frame(root, bg='#f0f0f0', bd=5)
border_frame.pack(expand=True, fill=tk.BOTH)

# Create a title label
title = tk.Label(border_frame, text="OSINT Github Tools", font=("Helvetica", 24, "bold"), fg="red", bg="black")
title.pack(pady=10)

# Create a style for the button
style = ttk.Style()
style.configure('Custom.TButton', foreground='white', background='#007acc', font=('Helvetica', 14))

# Load the PDF icon image
pdf_icon = Image.open('pdf_icon.png')
pdf_icon = pdf_icon.resize((16, 16))
pdf_icon = ImageTk.PhotoImage(pdf_icon)

# Create a canvas to hold the categories and tools with a scrollbar
canvas = tk.Canvas(border_frame, bg='#f0f0f0')
canvas.pack(side=tk.LEFT, expand=True, fill=tk.BOTH)

# Create a vertical scrollbar for the canvas
scrollbar = ttk.Scrollbar(border_frame, orient=tk.VERTICAL, command=canvas.yview)
scrollbar.pack(side=tk.LEFT, fill=tk.Y)

canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda event: canvas.configure(scrollregion=canvas.bbox("all")))

# Create a frame to hold the content within the canvas
content_frame = tk.Frame(canvas, bg='#f0f0f0')
canvas.create_window((0, 0), window=content_frame, anchor=tk.NW)

# Define categories and tools
# ... (previous code) ...

# Create lists of tool names and PDF file names for each category
# Add more categories as needed
category1_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
# ... (add more categories with their respective tools) ...
category2_tools = [('Tool 3', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 4', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]

category6_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
# Create a dictionary to map category names to their corresponding tool and PDF lists
category_data = {'Category 1': category1_tools,
                 'Category 2': category2_tools,
                 # ... (add more categories) ...
                 'Category 6': category6_tools}

# Create a frame for the category buttons
category_frame = tk.Frame(content_frame, bg='#f0f0f0')
category_frame.pack(pady=10)

# Function to show the tools and PDFs for a selected category
# ... (previous code) ...
# Create a frame for the category buttons
category_frame = tk.Frame(content_frame, bg='#f0f0f0')
category_frame.pack(pady=10)

# Function to show the tools and PDFs for a selected category or all categories
def show_tools(category):
    # Clear the current buttons
    for child in button_frame.winfo_children():
        child.destroy()

    if category is None:
        # Show all categories and their tools
        for cat in category_data.keys():
            # Add category label
            cat_label = tk.Label(button_frame, text=cat, font=("Helvetica", 14, "bold"), bg='#f0f0f0', fg="blue")
            cat_label.pack(side=tk.TOP, pady=(10, 0))

            for name, pdf_file, tool_path in category_data[cat]:
                # Create a frame for the tool button and PDF button
                button_row = tk.Frame(button_frame, bg='#f0f0f0')
                button_row.pack(side=tk.TOP, pady=5)

                # Create the PDF button with a title
                pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                                        command=lambda path=pdf_file: open_pdf(path))
                pdf_button.pack(side=tk.LEFT)

                # Create the tool button
                tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                                         command=lambda path=tool_path: launch_tool(path))
                tool_button.pack(side=tk.LEFT, padx=10, pady=5)
    else:
        # Show only the selected category's tools
        for name, pdf_file, tool_path in category_data[category]:
            # Create a frame for the tool button and PDF button
            button_row = tk.Frame(button_frame, bg='#f0f0f0')
            button_row.pack(side=tk.TOP, pady=5)

            # Create the PDF button with a title
            pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                                    command=lambda path=pdf_file: open_pdf(path))
            pdf_button.pack(side=tk.LEFT)

            # Create the tool button
            tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                                     command=lambda path=tool_path: launch_tool(path))
            tool_button.pack(side=tk.LEFT, padx=10, pady=5)


# Create category buttons and bind them to the show_tools function
# ... (previous code) ...

# Create a button to show all tools and PDFs for each category
show_all_button = ttk.Button(content_frame, text='Show All', style='Custom.TButton', command=lambda: show_tools(None))
show_all_button.pack(pady=10)

# Create a frame to hold the tool and PDF buttons
button_frame = tk.Frame(content_frame, bg='#f0f0f0')
button_frame.pack(pady=20)

# Run the main loop
root.mainloop()
