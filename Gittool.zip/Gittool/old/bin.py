import tkinter as tk
import threading

# Function to continuously update a label with binary representation of counter
def update_binary_label():
    global counter
    binary_str = bin(counter)[2:]  # Convert counter to binary string
    binary_label.config(text=binary_str.zfill(16))  # Update label with binary string, padded with leading zeros to 16 bits
    counter += 1  # Increment counter
    binary_label.after(100, update_binary_label)  # Schedule function to run again after 100 milliseconds

# Create the main window
root = tk.Tk()
root.title("My Application")

# Create a frame for the binary label
binary_frame = tk.Frame(root)
binary_frame.pack(side=tk.BOTTOM)

# Create a label to display the binary string
binary_label = tk.Label(binary_frame, text="", font=("Courier", 24), fg="white", bg="#007acc")
binary_label.pack()

# Start the update function in a separate thread
counter = 0
update_thread = threading.Thread(target=update_binary_label)
update_thread.start()

# Run the main loop
root.mainloop()
