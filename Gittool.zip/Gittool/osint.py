import tkinter as tk
from tkinter import ttk
from functools import partial
import json
import subprocess

# Tool structure
tool_structure = [
    {
        "category": "Category 1",
        "tools": [
            {
                "name": "Tool 1",
                "path": "/path/to/tool1",
                "pdf": "/path/to/tool1/docs/tool1.pdf",
                "help": "This is a help text for Tool 1."
            },
            {
                "name": "Tool 2",
                "path": "/path/to/tool2",
                "pdf": "/path/to/tool2/docs/tool2.pdf",
                "help": "This is a help text for Tool 2."
            },
        ]
    },
    {
        "category": "Category 2",
        "tools": [
            {
                "name": "Tool 3",
                "path": "/path/to/tool3",
                "pdf": "/path/to/tool3/docs/tool3.pdf",
                "help": "This is a help text for Tool 3."
            },
            {
                "name": "Tool 4",
                "path": "/path/to/tool4",
                "pdf": "/path/to/tool4/docs/tool4.pdf",
                "help": "This is a help text for Tool 4."
            },
        ]
    },
    {
        "category": "Category 3",
        "tools": [
            {
                "name": "Tool 5",
                "path": "/path/to/tool5",
                "pdf": "/path/to/tool5/docs/tool5.pdf",
                "help": "This is a help text for Tool 5."
            },
            {
                "name": "Tool 6",
                "path": "/path/to/tool6",
                "pdf": "/path/to/tool6/docs/tool6.pdf",
                "help": "This is a help text for Tool 6."
            },
        ]
    },
]

# The rest of the code remains unchanged

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])


# Function to expand or collapse a frame
def toggle_frame(frame, all_frames):
    expanded = False
    if frame.winfo_viewable():
        frame.grid_remove()
    else:
        frame.grid()
        expanded = True

    for other_frame in all_frames:
        if other_frame != frame:
            other_frame.grid_remove()
    return expanded


# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])


def create_tool_frame(parent, tool_info):
    tool_frame = ttk.Frame(parent)
    tool_frame.pack(side='top', pady=2)

    # Tool name button
    tool_button = ttk.Button(tool_frame, text=tool_info['name'], command=partial(launch_tool, tool_info['path']))
    tool_button.pack(side='left', padx=2)

    # PDF button
    pdf_button = ttk.Button(tool_frame, text="PDF", command=partial(open_pdf, tool_info['pdf']))
    pdf_button.pack(side='left', padx=2)

    # Hover help
    tool_button.bind('<Enter>', partial(show_hover_help, tool_info['help']))
    tool_button.bind('<Leave>', hide_hover_help)


def show_hover_help(help_text, event):
    x, y, _, _ = event.widget.bbox("insert")
    x += event.widget.winfo_rootx() + 25
    y += event.widget.winfo_rooty() + 25
    hover_help_window = tk.Toplevel(event.widget)
    hover_help_window.wm_overrideredirect(True)
    hover_help_window.wm_geometry(f"+{x}+{y}")
    label = tk.Label(hover_help_window, text=help_text, background="white", relief="solid", borderwidth=1)
    label.pack()
    event.widget.hover_help_window = hover_help_window


def hide_hover_help(event):
    if hasattr(event.widget, 'hover_help_window'):
        event.widget.hover_help_window.destroy()
        del event.widget.hover_help_window

def create_category_frame(parent, category, all_frames):
    category_frame = ttk.Frame(parent)
    category_frame.pack(side='top', pady=5)

    category_label = ttk.Label(category_frame, text=category['category'], font=('Helvetica', 14), anchor='w')
    category_label.pack(side='left', padx=10)

    toggle_button = ttk.Button(category_frame, text="+", command=lambda: toggle_category(category, all_frames))
    toggle_button.pack(side='left', padx=5)

    category['frame'].grid_remove()

def toggle_category(category, all_frames):
    expanded = toggle_frame(category['frame'], all_frames)
    if expanded:
        category['toggle_button'].config(text="-")
    else:
        category['toggle_button'].config(text="+")

def populate_tool_structure(parent, tool_structure):
    all_frames = [category['frame'] for category in tool_structure]
    
    for category in tool_structure:
        category['frame'] = ttk.Frame(parent)
        category['frame'].pack(side='top', padx=10)

        create_category_frame(parent, category, all_frames)

        for tool in category['tools']:
            create_tool_frame(category['frame'], tool)

def create_category_frame(parent, category):
    category_frame = ttk.Frame(parent)
    category_frame.pack(side='top', pady=5)

    category_label = ttk.Label(category_frame, text=category['category'], font=('Helvetica', 14), anchor='w')
    category_label.pack(side='left', padx=10)

    toggle_button = ttk.Button(category_frame, text="+", command=partial(toggle_frame, category['frame']))
    toggle_button.pack(side='left', padx=5)

    category['frame'].grid_remove()


def populate_tool_structure(parent, tool_structure):
    for category in tool_structure:
        category['frame'] = ttk.Frame(parent)
        category['frame'].pack(side='top', padx=10)

        create_category_frame(parent, category)

        for tool in category['tools']:
            create_tool_frame(category['frame'], tool)


root = tk.Tk()
root.title("OSINT Tools")

mainframe = ttk.Frame(root, padding="10 10 10 10")
mainframe.grid(column=0, row=0, sticky=('n', 'w', 'e', 's'))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

populate_tool_structure(mainframe, tool_structure)

root.mainloop()
