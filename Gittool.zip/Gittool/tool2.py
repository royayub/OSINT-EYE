import tkinter as tk
from tkinter import ttk
import subprocess
from PIL import Image, ImageTk

# Function to launch a tool terminal
def launch_tool(tool_path):
    subprocess.run(['gnome-terminal', '--working-directory=' + tool_path])

# Function to open the PDF document
def open_pdf(pdf_path):
    subprocess.run(['xdg-open', pdf_path])

# Create the main window
root = tk.Tk()
root.title("My Application")
root.geometry("400x400")
root.configure(bg='#f0f0f0')

# Create a style for the button
style = ttk.Style()
style.configure('Custom.TButton', foreground='white', background='#007acc', font=('Helvetica', 14))

# Load the PDF icon image
pdf_icon = Image.open('pdf_icon.png')
pdf_icon = pdf_icon.resize((16, 16))
pdf_icon = ImageTk.PhotoImage(pdf_icon)

# Create lists of tool names and PDF file names for each category
category1_tools = [('Tool 1', '/home/attacker/Documents/tool1.pdf', '/home/attacker/Desktop/tool1'),
                   ('Tool 2', '/home/attacker/Documents/tool2.pdf', '/home/attacker/Desktop/tool2')]
category2_tools = [('Tool 3', '/home/attacker/Documents/tool3.pdf', '/home/attacker/Desktop/tool3'),
                   ('Tool 4', '/home/attacker/Documents/tool4.pdf', '/home/attacker/Desktop/tool4')]
category3_tools = [('Tool 5', '/home/attacker/Documents/tool5.pdf', '/home/attacker/Desktop/tool5'),
                   ('Tool 6', '/home/attacker/Documents/tool6.pdf', '/home/attacker/Desktop/tool6')]
category4_tools = [('Tool 7', '/home/attacker/Documents/tool7.pdf', '/home/attacker/Desktop/tool7'),
                   ('Tool 8', '/home/attacker/Documents/tool8.pdf', '/home/attacker/Desktop/tool8')]

# Create a dictionary to map category names to their corresponding tool and PDF lists
category_data = {'Category 1': category1_tools, 'Category 2': category2_tools, 'Category 3': category3_tools, 'Category 4': category4_tools}

# Create a frame for the category buttons
category_frame = tk.Frame(root, bg='#f0f0f0')
category_frame.pack(pady=10)

# Create a list to store the category buttons
category_buttons = []

# Loop through the categories and create a button for each one
for category in category_data.keys():
    category_button = ttk.Button(category_frame, text=category, style='Custom.TButton')
    category_button.pack(side=tk.LEFT, padx=5)
    category_buttons.append(category_button)

# Create a frame for the tool and PDF buttons
button_frame = tk.Frame(root, bg='#f0f0f0')
button_frame.pack(pady=20)

# Create a button to show all tools and PDFs
show_all_button = ttk.Button(root, text='Show All', style='Custom.TButton')
show_all_button.pack(pady=10)

# Create a function to show the tools and PDFs for a specific category
def show_category(category):
    # Clear the current buttons
    for child in button_frame.winfo_children():
        child.destroy()

    # Loop through the tools and PDF files for the category and create a button for each one
    for name, pdf_file, tool_path in category_data[category]:
        # Create a frame for the tool button and PDF button
        button_row = tk.Frame(button_frame, bg='#f0f0f0')
    button_row.pack(side=tk.TOP, pady=5)

    # Create the PDF button with a title
    pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                            command=lambda path=pdf_file: open_pdf(path))
    pdf_button.pack(side=tk.LEFT)

    # Create the tool button
    tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                             command=lambda path=tool_path: launch_tool(path))
    tool_button.pack(side=tk.LEFT, padx=10, pady=5)
def show_all():
# Clear the current buttons
    for child in button_frame.winfo_children():
        child.destroy()
# Loop through all categories and their tools and PDF files and create a button for each one
for category in category_data.keys():
    for name, pdf_file, tool_path in category_data[category]:
        # Create a frame for the tool button and PDF button
        button_row = tk.Frame(button_frame, bg='#f0f0f0')
        button_row.pack(side=tk.TOP, pady=5)

        # Create the PDF button with a title
        pdf_button = ttk.Button(button_row, text=name + ' PDF', image=pdf_icon, compound='left',
                                command=lambda path=pdf_file: open_pdf(path))
        pdf_button.pack(side=tk.LEFT)

        # Create the tool button
        tool_button = ttk.Button(button_row, text=name, style='Custom.TButton',
                                 command=lambda path=tool_path: launch_tool(path))
        tool_button.pack(side=tk.LEFT, padx=10, pady=5)
for i, category_button in enumerate(category_buttons):
    category = list(category_data.keys())[i]
    category_button.bind('<Button-1>', lambda event, category=category: show_category(category))

    show_all_button.bind('<Button-1>', lambda event: show_all())
    root.mainloop()
    