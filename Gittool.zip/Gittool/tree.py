import tkinter as tk
from tkinter import ttk

def open_selected_item(event):
    selected_item = tree.selection()
    tool_name = tree.item(selected_item)['text']
    print(f"Launching {tool_name}...")

root = tk.Tk()
root.title("OSINT Tools")

tree = ttk.Treeview(root)
tree.pack(padx=10, pady=10)

# Add main categories
cat1 = tree.insert("", "end", text="Category 1")
cat2 = tree.insert("", "end", text="Category 2")
cat3 = tree.insert("", "end", text="Category 3")

# Add subcategories
subcat1 = tree.insert(cat1, "end", text="Subcategory 1")
subcat2 = tree.insert(cat1, "end", text="Subcategory 2")
subcat3 = tree.insert(cat2, "end", text="Subcategory 3")

# Add tools
tool_1 = tree.insert(subcat1, "end", text="Tool 1")
tool_2 = tree.insert(subcat2, "end", text="Tool 2")
tool_3 = tree.insert(subcat3, "end", text="Tool 3")

tree.bind("<Double-1>", open_selected_item)

root.mainloop()
